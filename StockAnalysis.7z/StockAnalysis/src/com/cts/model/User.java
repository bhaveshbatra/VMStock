package com.cts.model;

public class User {
	

	private int user_id;
	private String user_name;
	private String user_username;
	private String user_usertype;
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_username() {
		return user_username;
	}
	public void setUser_username(String user_username) {
		this.user_username = user_username;
	}
	public String getUser_usertype() {
		return user_usertype;
	}
	public void setUser_usertype(String user_usertype) {
		this.user_usertype = user_usertype;
	}
	public int getUser_phone() {
		return user_phone;
	}
	public void setUser_phone(int user_phone) {
		this.user_phone = user_phone;
	}
	public boolean isUser_confirmed() {
		return user_confirmed;
	}
	public void setUser_confirmed(boolean user_confirmed) {
		this.user_confirmed = user_confirmed;
	}
	private int user_phone;
	private boolean user_confirmed;

}
