package com.cts.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {
	
	@RequestMapping("/adminRegister")
	public String display()
	{
		return "adminregister.jsp";
	}
	
	

}
